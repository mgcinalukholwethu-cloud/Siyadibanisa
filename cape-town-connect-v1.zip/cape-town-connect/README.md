# Cape Town Connect — Version 1

A mobile-first local marketplace starter built with Vite, vanilla JavaScript and Supabase.

## Requirements

- Node.js 20.19+ or 22.12+
- A Supabase project
- Your existing Cape Town Connect database schema

## 1. Install

```bash
npm install
```

## 2. Configure Supabase

Copy `.env.example` to `.env` in the project root.

Add your Supabase Project URL and your **publishable key** (or legacy anon key):

```env
VITE_SUPABASE_URL=https://YOUR_PROJECT_REF.supabase.co
VITE_SUPABASE_ANON_KEY=YOUR_PUBLISHABLE_OR_ANON_KEY
```

Never put your `service_role` key or Supabase secret key in frontend code.

Restart Vite after changing `.env`.

## 3. Run the additional Supabase SQL

In Supabase Dashboard → SQL Editor, run:

`supabase/setup_storage_and_location.sql`

This creates the public `listing-images` bucket, its upload/read/delete policies, and the `search_nearby_businesses` RPC function.

The bucket is public because published listing photographs need to be viewable by customers. Only authenticated owners can upload into their own business UUID folder. Do not store private or sensitive images in this bucket.

## 4. Start the app

```bash
npm run dev
```

Open the local URL Vite prints, usually http://localhost:5173.

## 5. Build for production

```bash
npm run build
npm run preview
```

## Current features

- Email/password registration and login
- Customer, provider or both account types
- Public browsing of verified businesses' active listings
- Category and suburb filters
- Business registration (new businesses are pending review)
- Product/service listing creation
- Listing photo upload to Supabase Storage
- Customer enquiries
- Browser geolocation and PostGIS nearby search
- Mobile-first responsive UI

## Important database notes

This starter expects the eight tables from the initial Cape Town Connect schema:
`profiles`, `categories`, `subcategories`, `businesses`, `listings`,
`service_areas`, `inquiries`, and `reviews`.

It expects the profile trigger to create a profile row when a user signs up.

### Publishing listings

The app initially saves new listings with `status = 'draft'`. This is deliberate: the current business approval flow is manual. Once an administrator verifies a business, an administrator can publish a listing by changing its status to `active` in Supabase Table Editor.

### Nearby search

The business registration form has an optional consent checkbox to use the browser's current coordinates as the public business/service location. Providers should only enable it if that location is safe to show customers; home-based vendors should leave it off and use suburb search/service areas instead. The `search_nearby_businesses` function only finds businesses with a populated `businesses.location` geography point.

### Security review before launch

- Confirm RLS is enabled on all exposed tables.
- Confirm your policies allow the intended operations and prevent users changing their own verification status.
- Add secure administrator roles and policies before building an admin UI.
- Review inquiry update permissions before adding provider responses.
- Consider email confirmation, password recovery, rate limits, abuse reporting and POPIA notices.
- Keep service-role/secret keys server-side only.
