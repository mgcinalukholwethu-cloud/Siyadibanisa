import { supabase } from '../lib/supabase.js';

function requireSupabase() {
  if (!supabase) throw new Error('Supabase is not configured. Check your .env file and restart the dev server.');
}

export async function getCategories() {
  requireSupabase();
  const { data, error } = await supabase
    .from('categories')
    .select('id, category_name, slug, icon')
    .eq('is_active', true)
    .order('category_name');
  if (error) throw error;
  return data ?? [];
}

export async function getMarketplace({ search = '', categoryId = '', suburb = '' } = {}) {
  requireSupabase();

  let query = supabase
    .from('listings')
    .select(`
      id, title, description, listing_type, price, pricing_type, image_url, created_at,
      businesses!inner (
        id, business_name, description, suburb, city, phone_number, whatsapp_number,
        verification_status, category_id,
        categories ( category_name, slug )
      )
    `)
    .eq('status', 'active')
    .eq('businesses.verification_status', 'verified')
    .order('created_at', { ascending: false })
    .limit(60);

  if (search.trim()) query = query.ilike('title', `%${search.trim()}%`);
  if (categoryId) query = query.eq('businesses.category_id', categoryId);
  if (suburb.trim()) query = query.ilike('businesses.suburb', `%${suburb.trim()}%`);

  const { data, error } = await query;
  if (error) throw error;
  return data ?? [];
}

export async function getNearbyBusinesses({ latitude, longitude, radius = 5000, categoryId = '' }) {
  requireSupabase();
  const { data, error } = await supabase.rpc('search_nearby_businesses', {
    user_lat: latitude,
    user_lng: longitude,
    radius_m: radius,
    category_filter: categoryId || null
  });
  if (error) throw error;
  return data ?? [];
}

export async function createBusiness(values) {
  requireSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('Please sign in before registering a business.');

  const payload = {
    ...values,
    owner_id: user.id,
    verification_status: 'pending'
  };

  const { data, error } = await supabase
    .from('businesses')
    .insert(payload)
    .select()
    .single();

  if (error) throw error;
  return data;
}

export async function createListing(values) {
  requireSupabase();
  const { data, error } = await supabase
    .from('listings')
    .insert(values)
    .select()
    .single();
  if (error) throw error;
  return data;
}

export async function getMyBusinesses() {
  requireSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return [];

  const { data, error } = await supabase
    .from('businesses')
    .select('id, business_name, suburb, verification_status, category_id')
    .eq('owner_id', user.id)
    .order('created_at', { ascending: false });

  if (error) throw error;
  return data ?? [];
}

export async function getMyInquiries() {
  requireSupabase();
  const { data, error } = await supabase
    .from('inquiries')
    .select(`
      id, subject, description, requested_area, status, created_at,
      businesses ( id, business_name )
    `)
    .order('created_at', { ascending: false })
    .limit(50);
  if (error) throw error;
  return data ?? [];
}

export async function createInquiry({ businessId, listingId, subject, description, requestedArea }) {
  requireSupabase();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) throw new Error('Please sign in to contact this provider.');

  const { data, error } = await supabase.from('inquiries').insert({
    customer_id: user.id,
    business_id: businessId,
    listing_id: listingId || null,
    subject,
    description,
    requested_area: requestedArea || null
  }).select().single();

  if (error) throw error;
  return data;
}
