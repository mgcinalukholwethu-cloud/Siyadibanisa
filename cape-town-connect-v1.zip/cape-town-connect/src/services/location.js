export function getCurrentPosition() {
  return new Promise((resolve, reject) => {
    if (!('geolocation' in navigator)) {
      reject(new Error('Location is not supported by this browser.'));
      return;
    }

    navigator.geolocation.getCurrentPosition(
      ({ coords }) => resolve({
        latitude: coords.latitude,
        longitude: coords.longitude
      }),
      (error) => {
        const messages = {
          1: 'Location permission was denied. You can still search by suburb.',
          2: 'Your location could not be determined. Try searching by suburb.',
          3: 'Location request timed out. Please try again.'
        };
        reject(new Error(messages[error.code] || 'Unable to get your location.'));
      },
      { enableHighAccuracy: false, timeout: 10000, maximumAge: 60000 }
    );
  });
}
