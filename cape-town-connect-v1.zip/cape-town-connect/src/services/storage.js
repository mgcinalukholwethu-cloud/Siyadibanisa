import { supabase } from '../lib/supabase.js';

export async function uploadListingImage(file, businessId) {
  if (!supabase) throw new Error('Supabase is not configured.');
  if (!file) return null;

  const allowed = ['image/jpeg', 'image/png', 'image/webp'];
  if (!allowed.includes(file.type)) {
    throw new Error('Please upload a JPG, PNG or WebP image.');
  }
  if (file.size > 5 * 1024 * 1024) {
    throw new Error('Image must be 5 MB or smaller.');
  }

  const extension = file.name.split('.').pop()?.toLowerCase() || 'jpg';
  const fileName = `${crypto.randomUUID()}.${extension}`;
  const path = `${businessId}/${fileName}`;

  const { error } = await supabase.storage
    .from('listing-images')
    .upload(path, file, {
      cacheControl: '3600',
      upsert: false,
      contentType: file.type
    });

  if (error) throw error;

  const { data } = supabase.storage
    .from('listing-images')
    .getPublicUrl(path);

  return data.publicUrl;
}
