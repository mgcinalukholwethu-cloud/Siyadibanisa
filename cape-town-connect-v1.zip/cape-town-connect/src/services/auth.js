import { supabase } from '../lib/supabase.js';

function requireSupabase() {
  if (!supabase) throw new Error('Supabase is not configured. Check your .env file.');
}

export async function signUp({ fullName, email, password, accountType }) {
  requireSupabase();
  const { data, error } = await supabase.auth.signUp({
    email,
    password,
    options: {
      data: { full_name: fullName, account_type: accountType }
    }
  });
  if (error) throw error;

  // The database trigger creates the profile. If email confirmation is disabled
  // and a session is returned, update the account type chosen during registration.
  if (data.user && data.session) {
    const { error: profileError } = await supabase
      .from('profiles')
      .update({ account_type: accountType })
      .eq('id', data.user.id);
    if (profileError) throw profileError;
  }

  return data;
}

export async function signIn({ email, password }) {
  requireSupabase();
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) throw error;
  return data;
}

export async function signOut() {
  requireSupabase();
  const { error } = await supabase.auth.signOut();
  if (error) throw error;
}

export async function getSession() {
  if (!supabase) return null;
  const { data, error } = await supabase.auth.getSession();
  if (error) throw error;
  return data.session;
}
