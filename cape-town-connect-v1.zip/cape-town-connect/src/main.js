import './style.css';
import { supabase } from './lib/supabase.js';
import { signIn, signUp, signOut, getSession } from './services/auth.js';
import {
  getCategories, getMarketplace, getNearbyBusinesses, createBusiness,
  createListing, getMyBusinesses, getMyInquiries, createInquiry
} from './services/data.js';
import { uploadListingImage } from './services/storage.js';
import { getCurrentPosition } from './services/location.js';

const app = document.querySelector('#app');
let session = null;
let categories = [];
let listings = [];
let activeCategory = '';
let searchTerm = '';
let suburbTerm = '';
let currentView = 'home';
let selectedListing = null;

const escapeHtml = (value = '') => String(value).replace(/[&<>"']/g, char => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'
}[char]));

const money = (price, pricingType) => {
  if (pricingType === 'quote' || price === null || price === undefined) return 'Request a quote';
  return `From R${Number(price).toLocaleString('en-ZA', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}`;
};

function toast(message, type = 'info') {
  const old = document.querySelector('.toast');
  if (old) old.remove();
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = message;
  document.body.append(el);
  setTimeout(() => el.remove(), 4200);
}

function setBusy(button, busy, label = 'Please wait…') {
  if (!button) return;
  if (busy) {
    button.dataset.original = button.textContent;
    button.disabled = true;
    button.textContent = label;
  } else {
    button.disabled = false;
    button.textContent = button.dataset.original || 'Submit';
  }
}

function header() {
  const userName = session?.user?.user_metadata?.full_name || session?.user?.email || '';
  return `
    <header class="site-header">
      <a class="brand" href="#" data-view="home" aria-label="Cape Town Connect home">
        <span class="brand-mark">C</span>
        <span><strong>Cape Town</strong><small>CONNECT</small></span>
      </a>
      <nav class="desktop-nav">
        <a href="#explore" data-view="home">Explore</a>
        <a href="#how-it-works" data-scroll="how-it-works">How it works</a>
        ${session ? '<a href="#dashboard" data-view="dashboard">My dashboard</a>' : ''}
      </nav>
      <div class="header-actions">
        ${session
          ? `<span class="welcome-user">${escapeHtml(userName)}</span><button class="btn btn-outline btn-small" id="logout-btn">Log out</button>`
          : '<button class="btn btn-outline btn-small" id="login-open">Log in</button><button class="btn btn-primary btn-small" id="register-open">Join free</button>'}
      </div>
    </header>`;
}

function categoryIcon(slug) {
  const icons = {
    plumbing: '🔧', 'electrical-services': '⚡', cleaning: '🧹',
    construction: '🧱', 'hair-and-beauty': '💇', automotive: '🚗',
    'car-wash-services': '🚿', 'food-and-catering': '🍲',
    'clothing-and-fashion': '👕', electronics: '📱',
    'home-maintenance': '🏠', transportation: '🚚',
    'retail-and-groceries': '🛒', 'professional-services': '💼'
  };
  return icons[slug] || '📍';
}

function categoryMarkup() {
  return `
    <div class="category-strip">
      <button class="category-chip ${!activeCategory ? 'active' : ''}" data-category="">🌍 <span>All</span></button>
      ${categories.map(c => `
        <button class="category-chip ${activeCategory === c.id ? 'active' : ''}" data-category="${c.id}">
          ${categoryIcon(c.slug)} <span>${escapeHtml(c.category_name)}</span>
        </button>`).join('')}
    </div>`;
}

function listingCard(item) {
  const business = item.businesses || {};
  const image = item.image_url
    ? `<img src="${escapeHtml(item.image_url)}" alt="${escapeHtml(item.title)}" loading="lazy">`
    : `<div class="image-placeholder"><span>${categoryIcon(business.categories?.slug)}</span><small>Local business</small></div>`;
  return `
    <article class="listing-card">
      <button class="listing-image" data-listing="${item.id}" aria-label="View ${escapeHtml(item.title)}">
        ${image}
        <span class="type-pill">${item.listing_type === 'service' ? 'Service' : 'Product'}</span>
      </button>
      <div class="listing-info">
        <div class="eyebrow">${escapeHtml(business.categories?.category_name || 'Local business')}</div>
        <h3>${escapeHtml(item.title)}</h3>
        <p class="listing-description">${escapeHtml(item.description || 'Contact this provider for more information.')}</p>
        <div class="listing-meta"><span>📍 ${escapeHtml(business.suburb || 'Cape Town')}</span><strong>${money(item.price, item.pricing_type)}</strong></div>
        <div class="business-line"><span class="business-avatar">${escapeHtml((business.business_name || 'B').slice(0, 1).toUpperCase())}</span><span>${escapeHtml(business.business_name || 'Local provider')}</span></div>
        <button class="btn btn-outline btn-full" data-listing="${item.id}">View details</button>
      </div>
    </article>`;
}

function homeView() {
  return `
    <main>
      <section class="hero">
        <div class="hero-copy">
          <span class="hero-kicker"><span class="pulse"></span> YOUR CITY. YOUR PEOPLE. YOUR CONNECT.</span>
          <h1>Discover local.<br><em>Support local.</em></h1>
          <p>Find trusted local businesses, talented service providers and independent vendors around Cape Town.</p>
          <form class="search-panel" id="search-form">
            <label class="search-field"><span>⌕</span><input id="search-input" type="search" placeholder="What are you looking for?" value="${escapeHtml(searchTerm)}"></label>
            <label class="search-field location-field"><span>⌖</span><input id="suburb-input" type="text" placeholder="Suburb or area" value="${escapeHtml(suburbTerm)}"></label>
            <button class="btn btn-primary" type="submit">Search</button>
          </form>
          <button class="location-link" id="near-me-btn">◎ Find services near my location</button>
        </div>
        <div class="hero-art" aria-hidden="true">
          <div class="hero-orbit orbit-one"></div><div class="hero-orbit orbit-two"></div>
          <div class="hero-pin pin-one">🔧<small>Plumbing</small></div>
          <div class="hero-pin pin-two">🚿<small>Car wash</small></div>
          <div class="hero-pin pin-three">🍲<small>Food</small></div>
          <div class="hero-center"><span>CT</span><strong>LOCAL<br>CONNECT</strong><small>CAPE TOWN, SA</small></div>
        </div>
      </section>

      <section class="section" id="explore">
        <div class="section-heading">
          <div><span class="eyebrow">EXPLORE THE COMMUNITY</span><h2>What do you need today?</h2><p>Find the right people for the job.</p></div>
          <button class="text-button" id="clear-filters">Clear filters ↗</button>
        </div>
        ${categoryMarkup()}
      </section>

      <section class="section listings-section">
        <div class="section-heading">
          <div><span class="eyebrow">LOCAL MARKETPLACE</span><h2>Discover what's nearby</h2><p id="results-caption">Explore services and products from local providers.</p></div>
        </div>
        <div id="listing-results" class="listing-grid">
          ${listings.length ? listings.map(listingCard).join('') : '<div class="empty-state"><span>🌱</span><h3>Your local marketplace starts here</h3><p>Once verified providers publish listings, you will find them here.</p></div>'}
        </div>
      </section>

      <section class="community-band" id="how-it-works">
        <div><span class="eyebrow">GOOD THINGS HAPPEN LOCALLY</span><h2>One city. Countless connections.</h2><p>Whether you need a service or have a business to grow, Cape Town Connect brings the community closer.</p></div>
        <button class="btn btn-light" id="community-join">List your business <span>→</span></button>
      </section>
    </main>`;
}

function dashboardView() {
  return `
    <main class="dashboard-page">
      <div class="dashboard-heading"><div><span class="eyebrow">YOUR SPACE</span><h1>My dashboard</h1><p>Manage your local business and customer requests.</p></div></div>
      <div class="dashboard-grid">
        <section class="panel">
          <span class="eyebrow">BUSINESS PROFILE</span><h2>Register a business</h2>
          <p class="muted">Tell Cape Town what you offer. New businesses are reviewed before appearing publicly.</p>
          <form id="business-form" class="form-stack">
            <label>Business name<input name="business_name" required maxlength="100" placeholder="e.g. Thando Plumbing Services"></label>
            <label>Business category<select name="category_id" required><option value="">Choose a category</option>${categories.map(c => `<option value="${c.id}">${escapeHtml(c.category_name)}</option>`).join('')}</select></label>
            <label>Subcategory (optional)<select name="subcategory_id"><option value="">Choose a subcategory</option></select></label>
            <label>Short description<textarea name="description" rows="3" placeholder="Describe your business and what you offer"></textarea></label>
            <div class="form-two"><label>Phone number<input name="phone_number" type="tel" placeholder="e.g. 082 123 4567"></label><label>WhatsApp number<input name="whatsapp_number" type="tel" placeholder="e.g. 082 123 4567"></label></div>
            <label>Email address<input name="email" type="email" placeholder="Business email (optional)"></label>
            <div class="form-two"><label>Suburb / area<input name="suburb" required placeholder="e.g. Khayelitsha"></label><label>City<input name="city" value="Cape Town" required></label></div>
            <label class="consent-row"><input name="use_location" type="checkbox" value="yes"><span>Use my current location as the public business/service location (optional). Only select this if it is safe to show this approximate business location to customers.</span></label>
            <button class="btn btn-primary" type="submit">Submit business for review</button>
          </form>
        </section>
        <section class="panel">
          <span class="eyebrow">YOUR LISTINGS</span><h2>Add a product or service</h2>
          <p class="muted">You need a registered business before adding listings.</p>
          <form id="listing-form" class="form-stack">
            <label>Select your business<select name="business_id" id="listing-business" required><option value="">Loading your businesses…</option></select></label>
            <label>Listing title<input name="title" required maxlength="120" placeholder="e.g. Full car wash"></label>
            <label>Listing type<select name="listing_type" required><option value="service">Service</option><option value="product">Product</option></select></label>
            <label>Description<textarea name="description" rows="3" placeholder="Explain what the customer receives"></textarea></label>
            <div class="form-two"><label>Price (R)<input name="price" type="number" min="0" step="0.01" placeholder="Leave blank for quote"></label><label>Pricing type<select name="pricing_type"><option value="fixed">Fixed price</option><option value="starting_from">Starting from</option><option value="hourly">Hourly</option><option value="quote">Request a quote</option></select></label></div>
            <label>Listing photograph (JPG, PNG or WebP; max 5 MB)<input name="image" type="file" accept="image/jpeg,image/png,image/webp"></label>
            <button class="btn btn-primary" type="submit">Save listing</button>
          </form>
        </section>
      </div>
      <section class="panel dashboard-lower"><span class="eyebrow">BUSINESS OVERVIEW</span><h2>Your registered businesses</h2><div id="my-businesses" class="business-list"><p class="muted">Loading…</p></div></section>
      <section class="panel dashboard-lower"><span class="eyebrow">CUSTOMER ACTIVITY</span><h2>Enquiries</h2><div id="my-inquiries" class="business-list"><p class="muted">Loading…</p></div></section>
    </main>`;
}

function modalShell() {
  return `<div class="modal-backdrop" id="modal-backdrop" hidden><section class="modal" role="dialog" aria-modal="true" aria-labelledby="modal-title"><button class="modal-close" id="modal-close" aria-label="Close">×</button><div id="modal-content"></div></section></div>`;
}

function render() {
  app.innerHTML = `${header()}${currentView === 'dashboard' ? dashboardView() : homeView()}${modalShell()}<footer class="footer"><div class="brand footer-brand"><span class="brand-mark">C</span><span><strong>Cape Town</strong><small>CONNECT</small></span></div><p>Discover local. Support local. Connect locally.</p><small>© ${new Date().getFullYear()} Cape Town Connect</small></footer>`;
  bindGlobalEvents();
  if (currentView === 'dashboard' && session) loadDashboardData();
}

function showModal(content) {
  const backdrop = document.querySelector('#modal-backdrop');
  document.querySelector('#modal-content').innerHTML = content;
  backdrop.hidden = false;
  document.body.classList.add('modal-open');
}

function closeModal() {
  const backdrop = document.querySelector('#modal-backdrop');
  if (backdrop) backdrop.hidden = true;
  document.body.classList.remove('modal-open');
}

function authModal(mode = 'login') {
  const register = mode === 'register';
  showModal(`
    <span class="eyebrow">WELCOME TO THE COMMUNITY</span>
    <h2 id="modal-title">${register ? 'Create your account' : 'Welcome back'}</h2>
    <p class="muted">${register ? 'Join Cape Town Connect as a customer or local provider.' : 'Log in to continue connecting locally.'}</p>
    <form id="auth-form" class="form-stack">
      ${register ? '<label>Full name<input name="full_name" required autocomplete="name"></label>' : ''}
      <label>Email address<input name="email" type="email" required autocomplete="email"></label>
      <label>Password<input name="password" type="password" required minlength="6" autocomplete="${register ? 'new-password' : 'current-password'}"></label>
      ${register ? '<label>How will you use Cape Town Connect?<select name="account_type"><option value="customer">I am looking for local products or services</option><option value="provider">I want to advertise my business</option><option value="both">Both — I am a customer and a provider</option></select></label>' : ''}
      <button class="btn btn-primary btn-full" type="submit">${register ? 'Create account' : 'Log in'}</button>
    </form>
    <p class="switch-auth">${register ? 'Already have an account?' : 'New to Cape Town Connect?'} <button class="text-button" id="switch-auth">${register ? 'Log in' : 'Create an account'}</button></p>
  `);
  document.querySelector('#switch-auth').addEventListener('click', () => authModal(register ? 'login' : 'register'));
  document.querySelector('#auth-form').addEventListener('submit', handleAuth);
}

async function handleAuth(event) {
  event.preventDefault();
  const form = event.currentTarget;
  const button = form.querySelector('button[type="submit"]');
  setBusy(button, true);
  const values = Object.fromEntries(new FormData(form).entries());
  try {
    if (values.full_name) {
      const result = await signUp({
        fullName: values.full_name,
        email: values.email,
        password: values.password,
        accountType: values.account_type
      });
      if (!result.session) {
        toast('Account created. Check your email to confirm your address, then log in.', 'success');
        closeModal();
        return;
      }
      session = result.session;
      toast('Welcome to Cape Town Connect!', 'success');
    } else {
      const result = await signIn({ email: values.email, password: values.password });
      session = result.session;
      toast('You are now logged in.', 'success');
    }
    closeModal();
    currentView = 'home';
    render();
  } catch (error) {
    toast(error.message || 'Unable to authenticate.', 'error');
  } finally {
    setBusy(button, false);
  }
}

function bindGlobalEvents() {
  document.querySelector('#login-open')?.addEventListener('click', () => authModal('login'));
  document.querySelector('#register-open')?.addEventListener('click', () => authModal('register'));
  document.querySelector('#community-join')?.addEventListener('click', () => {
    if (!session) authModal('register');
    else { currentView = 'dashboard'; render(); }
  });
  document.querySelector('#logout-btn')?.addEventListener('click', async () => {
    try { await signOut(); session = null; currentView = 'home'; render(); toast('You have logged out.'); }
    catch (error) { toast(error.message, 'error'); }
  });
  document.querySelectorAll('[data-view]').forEach(el => el.addEventListener('click', event => {
    event.preventDefault();
    if (el.dataset.view === 'dashboard' && !session) { authModal('login'); return; }
    currentView = el.dataset.view;
    render();
  }));
  document.querySelectorAll('[data-scroll]').forEach(el => el.addEventListener('click', event => {
    event.preventDefault();
    document.getElementById(el.dataset.scroll)?.scrollIntoView({ behavior: 'smooth' });
  }));
  document.querySelectorAll('[data-category]').forEach(el => el.addEventListener('click', async () => {
    activeCategory = el.dataset.category;
    await refreshMarketplace();
  }));
  document.querySelector('#search-form')?.addEventListener('submit', async event => {
    event.preventDefault();
    searchTerm = document.querySelector('#search-input').value;
    suburbTerm = document.querySelector('#suburb-input').value;
    await refreshMarketplace();
  });
  document.querySelector('#clear-filters')?.addEventListener('click', async () => {
    activeCategory = ''; searchTerm = ''; suburbTerm = '';
    await refreshMarketplace();
  });
  document.querySelector('#near-me-btn')?.addEventListener('click', searchNearMe);
  document.querySelectorAll('[data-listing]').forEach(el => el.addEventListener('click', () => {
    selectedListing = listings.find(item => item.id === el.dataset.listing);
    if (selectedListing) listingModal(selectedListing);
  }));
  document.querySelector('#modal-close')?.addEventListener('click', closeModal);
  document.querySelector('#modal-backdrop')?.addEventListener('click', event => {
    if (event.target.id === 'modal-backdrop') closeModal();
  });
}

async function refreshMarketplace() {
  const results = document.querySelector('#listing-results');
  if (results) results.innerHTML = '<div class="loading-state">Finding local businesses…</div>';
  try {
    listings = await getMarketplace({ search: searchTerm, categoryId: activeCategory, suburb: suburbTerm });
    if (results) results.innerHTML = listings.length
      ? listings.map(listingCard).join('')
      : '<div class="empty-state"><span>🔎</span><h3>No listings found yet</h3><p>Try another category or suburb. New local businesses will appear as they are approved.</p></div>';
    const caption = document.querySelector('#results-caption');
    if (caption) caption.textContent = `${listings.length} listing${listings.length === 1 ? '' : 's'} found.`;
    document.querySelectorAll('[data-category]').forEach(el => el.classList.toggle('active', el.dataset.category === activeCategory));
    document.querySelectorAll('[data-listing]').forEach(el => el.addEventListener('click', () => {
      selectedListing = listings.find(item => item.id === el.dataset.listing);
      if (selectedListing) listingModal(selectedListing);
    }));
  } catch (error) {
    if (results) results.innerHTML = `<div class="empty-state"><h3>We couldn't load listings</h3><p>${escapeHtml(error.message)}</p></div>`;
  }
}

async function searchNearMe() {
  const button = document.querySelector('#near-me-btn');
  if (button) { button.disabled = true; button.textContent = 'Finding your location…'; }
  try {
    const position = await getCurrentPosition();
    const nearby = await getNearbyBusinesses({
      ...position,
      categoryId: activeCategory,
      radius: 10000
    });
    const results = document.querySelector('#listing-results');
    if (!nearby.length) {
      results.innerHTML = '<div class="empty-state"><span>📍</span><h3>No verified providers found within 10 km</h3><p>Try a larger area or search by suburb.</p></div>';
    } else {
      results.innerHTML = nearby.map(b => `
        <article class="listing-card nearby-card">
          <div class="image-placeholder"><span>📍</span><small>Nearby provider</small></div>
          <div class="listing-info"><div class="eyebrow">VERIFIED LOCAL BUSINESS</div><h3>${escapeHtml(b.business_name)}</h3><p>${escapeHtml(b.description || '')}</p><div class="listing-meta"><span>📍 ${escapeHtml(b.suburb)}</span><strong>${Number(b.distance_km).toFixed(1)} km away</strong></div></div>
        </article>`).join('');
    }
    document.querySelector('#results-caption').textContent = `Nearby businesses within 10 km of your location.`;
  } catch (error) {
    toast(error.message, 'error');
  } finally {
    if (button) { button.disabled = false; button.textContent = '◎ Find services near my location'; }
  }
}

function listingModal(item) {
  const business = item.businesses || {};
  showModal(`
    <span class="eyebrow">${escapeHtml(business.categories?.category_name || 'LOCAL LISTING')}</span>
    <h2 id="modal-title">${escapeHtml(item.title)}</h2>
    ${item.image_url ? `<img class="modal-listing-image" src="${escapeHtml(item.image_url)}" alt="${escapeHtml(item.title)}">` : ''}
    <p>${escapeHtml(item.description || 'Contact the provider for more information.')}</p>
    <div class="detail-box"><strong>${escapeHtml(business.business_name || '')}</strong><span>📍 ${escapeHtml(business.suburb || 'Cape Town')}</span><strong>${money(item.price, item.pricing_type)}</strong></div>
    <button class="btn btn-primary btn-full" id="contact-provider">Request a quote / contact provider</button>
    ${business.whatsapp_number ? `<a class="btn btn-outline btn-full whatsapp-link" target="_blank" rel="noopener" href="https://wa.me/${business.whatsapp_number.replace(/\D/g, '')}">Contact on WhatsApp</a>` : ''}
  `);
  document.querySelector('#contact-provider').addEventListener('click', () => {
    if (!session) { closeModal(); authModal('login'); toast('Log in to send an enquiry.'); return; }
    inquiryModal(item);
  });
}

function inquiryModal(item) {
  const business = item.businesses;
  showModal(`
    <span class="eyebrow">CONNECT WITH A PROVIDER</span><h2 id="modal-title">Send an enquiry</h2>
    <p class="muted">Your request will be sent to ${escapeHtml(business.business_name)}.</p>
    <form id="inquiry-form" class="form-stack">
      <label>Subject<input name="subject" required value="Enquiry about ${escapeHtml(item.title)}"></label>
      <label>What do you need?<textarea name="description" rows="4" required placeholder="Describe the service or product you need"></textarea></label>
      <label>Your area<input name="requested_area" placeholder="e.g. Site B, Khayelitsha"></label>
      <button class="btn btn-primary" type="submit">Send enquiry</button>
    </form>
  `);
  document.querySelector('#inquiry-form').addEventListener('submit', async event => {
    event.preventDefault();
    const button = event.currentTarget.querySelector('button');
    setBusy(button, true, 'Sending…');
    const values = Object.fromEntries(new FormData(event.currentTarget).entries());
    try {
      await createInquiry({
        businessId: item.businesses.id,
        listingId: item.id,
        subject: values.subject,
        description: values.description,
        requestedArea: values.requested_area
      });
      closeModal();
      toast('Your enquiry has been sent.', 'success');
    } catch (error) { toast(error.message, 'error'); }
    finally { setBusy(button, false); }
  });
}

async function loadDashboardData() {
  const businessSelect = document.querySelector('#listing-business');
  try {
    const businesses = await getMyBusinesses();
    businessSelect.innerHTML = businesses.length
      ? businesses.map(b => `<option value="${b.id}">${escapeHtml(b.business_name)} (${escapeHtml(b.verification_status)})</option>`).join('')
      : '<option value="">Register a business first</option>';
    document.querySelector('#my-businesses').innerHTML = businesses.length
      ? businesses.map(b => `<div class="business-row"><div><strong>${escapeHtml(b.business_name)}</strong><small>${escapeHtml(b.suburb)}</small></div><span class="status status-${b.verification_status}">${escapeHtml(b.verification_status)}</span></div>`).join('')
      : '<p class="muted">You have not registered a business yet.</p>';
    const inquiries = await getMyInquiries();
    document.querySelector('#my-inquiries').innerHTML = inquiries.length
      ? inquiries.map(i => `<div class="business-row"><div><strong>${escapeHtml(i.subject)}</strong><small>${escapeHtml(i.businesses?.business_name || '')} · ${new Date(i.created_at).toLocaleDateString()}</small></div><span class="status">${escapeHtml(i.status)}</span></div>`).join('')
      : '<p class="muted">No enquiries yet.</p>';
  } catch (error) {
    toast(error.message, 'error');
  }
}

function bindDashboardForms() {
  const categorySelect = document.querySelector('#business-form select[name="category_id"]');
  const subcategorySelect = document.querySelector('#business-form select[name="subcategory_id"]');
  categorySelect?.addEventListener('change', async () => {
    subcategorySelect.innerHTML = '<option value="">Loading…</option>';
    try {
      const { data, error } = await supabase.from('subcategories').select('id, subcategory_name').eq('category_id', categorySelect.value).order('subcategory_name');
      if (error) throw error;
      subcategorySelect.innerHTML = '<option value="">Choose a subcategory (optional)</option>' + (data || []).map(s => `<option value="${s.id}">${escapeHtml(s.subcategory_name)}</option>`).join('');
    } catch (error) { subcategorySelect.innerHTML = '<option value="">Subcategories unavailable</option>'; toast(error.message, 'error'); }
  });

  document.querySelector('#business-form')?.addEventListener('submit', async event => {
    event.preventDefault();
    const form = event.currentTarget;
    const button = form.querySelector('button[type="submit"]');
    setBusy(button, true, 'Submitting…');
    const v = Object.fromEntries(new FormData(form).entries());
    try {
      let publicLocation = null;
      if (v.use_location === 'yes') {
        const coordinates = await getCurrentPosition();
        // PostGIS geography(Point, 4326) accepts EWKT in longitude/latitude order.
        publicLocation = `SRID=4326;POINT(${coordinates.longitude} ${coordinates.latitude})`;
      }
      await createBusiness({
        business_name: v.business_name,
        location: publicLocation,
        category_id: v.category_id,
        subcategory_id: v.subcategory_id || null,
        description: v.description || null,
        phone_number: v.phone_number || null,
        whatsapp_number: v.whatsapp_number || null,
        email: v.email || null,
        suburb: v.suburb,
        city: v.city
      });
      form.reset();
      toast('Business submitted for review. It will not appear publicly until verified.', 'success');
      await loadDashboardData();
    } catch (error) { toast(error.message, 'error'); }
    finally { setBusy(button, false); }
  });

  document.querySelector('#listing-form')?.addEventListener('submit', async event => {
    event.preventDefault();
    const form = event.currentTarget;
    const button = form.querySelector('button[type="submit"]');
    setBusy(button, true, 'Saving listing…');
    const v = Object.fromEntries(new FormData(form).entries());
    try {
      if (!v.business_id) throw new Error('Register a business before creating a listing.');
      let imageUrl = null;
      if (v.image?.size) imageUrl = await uploadListingImage(v.image, v.business_id);
      await createListing({
        business_id: v.business_id,
        title: v.title,
        description: v.description || null,
        listing_type: v.listing_type,
        price: v.price === '' ? null : Number(v.price),
        pricing_type: v.pricing_type,
        image_url: imageUrl,
        status: 'draft'
      });
      form.reset();
      toast('Listing saved as a draft. Activate it after your business is verified.', 'success');
    } catch (error) { toast(error.message, 'error'); }
    finally { setBusy(button, false); }
  });
}

async function initialise() {
  if (supabase) {
    try {
      session = await getSession();
      supabase.auth.onAuthStateChange((_event, newSession) => {
        session = newSession;
        if (currentView === 'home') render();
      });
      categories = await getCategories();
      listings = await getMarketplace();
    } catch (error) {
      console.error(error);
      toast(error.message || 'Unable to load marketplace data.', 'error');
    }
  }
  render();
  if (currentView === 'dashboard') bindDashboardForms();
}

// Dashboard is rendered from render(); bind its form handlers after each render.
const originalRender = render;
render = function() {
  originalRender();
  if (currentView === 'dashboard' && session) bindDashboardForms();
};

initialise();
