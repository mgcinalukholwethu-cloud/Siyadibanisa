-- CAPE TOWN CONNECT: Storage bucket and nearby search function

-- 0. Keep the profile trigger in sync with registration metadata.
-- This preserves provider/both account types even when email confirmation
-- means signUp does not immediately return an authenticated session.
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = ''
AS $$
DECLARE
  requested_type text;
BEGIN
  requested_type := NEW.raw_user_meta_data ->> 'account_type';

  INSERT INTO public.profiles (id, full_name, account_type)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data ->> 'full_name', 'New User'),
    CASE
      WHEN requested_type IN ('customer', 'provider', 'both')
        THEN requested_type
      ELSE 'customer'
    END
  );

  RETURN NEW;
END;
$$;

-- Run this after your existing eight-table schema and RLS policies.
-- This script creates a PUBLIC listing-images bucket for public marketplace images.
-- Do not upload private documents or personal photos to this bucket.

-- 1. Create the public bucket (5 MB max, image types only)
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'listing-images',
  'listing-images',
  true,
  5242880,
  ARRAY['image/jpeg', 'image/png', 'image/webp']
)
ON CONFLICT (id) DO UPDATE SET
  public = EXCLUDED.public,
  file_size_limit = EXCLUDED.file_size_limit,
  allowed_mime_types = EXCLUDED.allowed_mime_types;

-- 2. Anyone can read public listing images
DROP POLICY IF EXISTS "Public can view listing images" ON storage.objects;
CREATE POLICY "Public can view listing images"
ON storage.objects FOR SELECT
TO anon, authenticated
USING (bucket_id = 'listing-images');

-- 3. A signed-in business owner can upload only into their business UUID folder
DROP POLICY IF EXISTS "Business owners upload listing images" ON storage.objects;
CREATE POLICY "Business owners upload listing images"
ON storage.objects FOR INSERT
TO authenticated
WITH CHECK (
  bucket_id = 'listing-images'
  AND EXISTS (
    SELECT 1
    FROM public.businesses b
    WHERE b.id::text = (storage.foldername(name))[1]
      AND b.owner_id = (SELECT auth.uid())
  )
);

-- 4. A business owner can delete files from their own business folder
DROP POLICY IF EXISTS "Business owners delete listing images" ON storage.objects;
CREATE POLICY "Business owners delete listing images"
ON storage.objects FOR DELETE
TO authenticated
USING (
  bucket_id = 'listing-images'
  AND EXISTS (
    SELECT 1
    FROM public.businesses b
    WHERE b.id::text = (storage.foldername(name))[1]
      AND b.owner_id = (SELECT auth.uid())
  )
);

-- 5. PostGIS nearby-business search
-- Business.location must contain a point. Providers must add coordinates before
-- they can appear in nearby searches.
CREATE OR REPLACE FUNCTION public.search_nearby_businesses(
  user_lat double precision,
  user_lng double precision,
  radius_m integer DEFAULT 5000,
  category_filter uuid DEFAULT NULL
)
RETURNS TABLE (
  id uuid,
  business_name text,
  description text,
  suburb text,
  category_id uuid,
  distance_km double precision
)
LANGUAGE sql
STABLE
SECURITY INVOKER
SET search_path = public, extensions
AS $$
  SELECT
    b.id,
    b.business_name,
    b.description,
    b.suburb,
    b.category_id,
    extensions.st_distance(
      b.location,
      extensions.st_setsrid(
        extensions.st_makepoint(user_lng, user_lat),
        4326
      )::extensions.geography
    ) / 1000.0 AS distance_km
  FROM public.businesses b
  WHERE b.verification_status = 'verified'
    AND b.location IS NOT NULL
    AND (category_filter IS NULL OR b.category_id = category_filter)
    AND extensions.st_dwithin(
      b.location,
      extensions.st_setsrid(
        extensions.st_makepoint(user_lng, user_lat),
        4326
      )::extensions.geography,
      LEAST(GREATEST(radius_m, 100), 50000)
    )
  ORDER BY distance_km ASC;
$$;

GRANT EXECUTE ON FUNCTION public.search_nearby_businesses(
  double precision, double precision, integer, uuid
) TO anon, authenticated;
